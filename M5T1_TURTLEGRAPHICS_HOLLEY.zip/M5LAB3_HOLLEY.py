#Marcus Holley
#October 20, 2017
#CTI 110
#M5LAB3


import turtle

#Turtle Setup
turtle.shape("turtle")
turtle.color("blue")
turtle.bgcolor("lightblue")
turtle.pensize(6)
turtle.setup(600, 400)

#Turtle Variable
flake = turtle
flake.color("white")
snowflake = turtle.Screen()
snowflake.title("Snowflake Attempt")

for s in range(10):
    for s in range(2):
        flake.forward(100)
        flake.right(60)
        flake.forward(100)
        flake.right(120)
    flake.right(36)


snowflake.exitonclick()
