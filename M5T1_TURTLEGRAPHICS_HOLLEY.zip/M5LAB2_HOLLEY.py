#Marcus Holley
#October 20, 2017
#CTI 110
#M5LAB2

import turtle

#Turtle Setup
turtle.shape("turtle")
turtle.color("orange")
turtle.setup(800, 600)
turtle.pensize(10)

initials = turtle.Screen()
initials.bgcolor("blue")
initials.title("My Initials")



#Turtle Variable
c=turtle
c.up()
c.setposition(-150, 0)
c.down()

#Directions for MH
c.left(90)
c.forward(90)
c.right(90)
c.right(45)
c.forward(45)
c.left(45)
c.left(90)
c.right(45)
c.forward(45)
c.right(90)
c.right(45)
c.forward(90)
c.penup()
c.left(45)
c.forward(90)
c.setposition(0, 90)
c.pendown()
c.right(45)
c.forward(90)
c.backward(45)
c.left(90)
c.forward(45)
c.left(90)
c.forward(45)
c.backward(90)

initials.exitonclick()
