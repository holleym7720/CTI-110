#Marcus Holley
#October 20, 2017
#CTI 110
#M5LAB1

import turtle

#Turtle Setup
from turtle import *
turtle.shape("turtle")
turtle.color("black")
turtle.bgcolor("orange")
turtle.pensize(10)
    
square = 0

while square<4:
    forward(150)
    right(90)
    forward(150)
    square=square+1




triangle = 0

while triangle<3:
    forward(150)
    left(120)
    triangle=triangle+1
    
exitonclick()
